﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class Register
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Dim i As New Integer

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        cmd = New OleDbCommand("insert into login values('" + TextBox1.Text + "','" + TextBox2.Text + "')", cn)
        i = cmd.ExecuteNonQuery()
        If i > 0 Then
            MsgBox("New User Register Success !", vbInformation)
        Else
            MsgBox("New User Register Failed !", vbCritical)
        End If
        TextBox1.Text = ""
        TextBox2.Text = ""
        cn.Close()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim str As String = ConfigurationManager.ConnectionStrings("dbcn").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
    End Sub
End Class
