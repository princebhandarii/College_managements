﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class Login
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cmd As OleDbCommand = New OleDbCommand("select * from login where [Username]='" + TextBox1.Text + "' and [Password]='" + TextBox2.Text + "'", cn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader

        If (dr.Read() = True) Then
            MsgBox("Login Successfully", MsgBoxStyle.Information)
            Response.Redirect("Daskboard.aspx")
        Else

            MsgBox("Login Failed", MsgBoxStyle.Critical)


        End If
        cn.Close()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim str As String = ConfigurationManager.ConnectionStrings("dbcn").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
    End Sub
End Class
