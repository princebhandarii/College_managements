﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class StudentAdd
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        cn.Open()


        If (txtStudentId.Text = "" Or txtStudentName.Text = "" Or txtAddress.Text = "" Or txtEmail.Text = "") Then
            MsgBox("Enter Field", MsgBoxStyle.Exclamation)
        Else


            cmd = New OleDbCommand("insert into StudentAdd(Student_Id,Student_Name,Gender,Mobile,Roll_Number,Class,Dob,Email,Address) values(" + txtStudentId.Text + ",'" + txtStudentName.Text + "','" + RadioButtonList1.SelectedValue + "','" + txtMobile.Text + "','" + txtRollNumber.Text + "','" + DropDownList1.Text + "','" + txtDob.Text + "','" + txtEmail.Text + "','" + txtAddress.Text + "')", cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("dbcn").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        da = New OleDbDataAdapter("select * from StudentAdd order by Student_Id", cn)
        ds = New DataSet()
        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

        cn.Close()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        data()
    End Sub

   

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        data()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtStudentId.Text = ""
        txtStudentName.Text = ""
        RadioButtonList1.ClearSelection()
        txtMobile.Text = ""
        txtRollNumber.Text = ""
        DropDownList1.ClearSelection()
        txtDob.Text = ""
        txtEmail.Text = ""
        txtAddress.Text = ""
    End Sub

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        cn.Open()
        If txtStudentId.Text = "" Then
            MsgBox("Enter Student_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("select * from StudentAdd where Student_Id=" + txtStudentId.Text, cn)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If

        cn.Close()
    End Sub

    Protected Sub btnfind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfind.Click
        cn.Open()
        If txtStudentId.Text = "" Then
            MsgBox("Enter Student_Id", MsgBoxStyle.Exclamation)
        Else
            Dim dr As OleDbDataReader
            cmd = New OleDbCommand("select * from StudentAdd where Student_Id=" + txtStudentId.Text, cn)
            dr = cmd.ExecuteReader()
            dr.Read()
            txtStudentName.Text = dr("Student_Name").ToString()
            RadioButtonList1.SelectedValue = dr("Gender").ToString()
            txtMobile.Text = dr("Mobile").ToString()
            txtRollNumber.Text = dr("Roll_Number").ToString()
            txtEmail.Text = dr("Email").ToString()
            txtDob.Text = dr("Dob").ToString()
            txtAddress.Text = dr("Address").ToString()
            DropDownList1.SelectedValue = dr("Class").ToString()

        End If

        cn.Close()
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        cn.Open()
        If txtStudentId.Text = "" Then
            MsgBox("Enter Student_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("delete from StudentAdd where Student_Id= " + txtStudentId.Text, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
        txtStudentId.Text = ""
        txtStudentName.Text = ""
        RadioButtonList1.ClearSelection()
        txtMobile.Text = ""
        txtRollNumber.Text = ""
        DropDownList1.ClearSelection()
        txtDob.Text = ""
        txtEmail.Text = ""
        txtAddress.Text = ""
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        cn.Open()
        If txtStudentId.Text = "" Then
            MsgBox("Enter Student_Id", MsgBoxStyle.Exclamation)
        Else

            Dim update As String
            update = "UPDATE StudentAdd SET [Student_Name]='" + txtStudentName.Text + "',[Gender]='" + RadioButtonList1.SelectedValue + "',[Mobile]='" + txtMobile.Text + "',[Roll_Number]='" + txtRollNumber.Text + "',[Class]='" + DropDownList1.SelectedValue + "',[Dob]='" + txtDob.Text + "',[Email]='" + txtEmail.Text + "',[Address]='" + txtAddress.Text + "' WHERE[Student_Id]=" + txtStudentId.Text + ""
            cmd = New OleDbCommand(update, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
    End Sub
End Class
