﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class Subject
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet

   

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        data()
    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("dbcn").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        da = New OleDbDataAdapter("select * from Subject order by Subject_Id", cn)
        ds = New DataSet()
        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

        cn.Close()

    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        cn.Open()
        If (TextBox1.Text = "" Or txtsubject.Text = "") Then
            MsgBox("Enter Field", MsgBoxStyle.Exclamation)
        Else
            cmd = New OleDbCommand("insert into Subject(Subject_Id,Class,Subject) values(" + TextBox1.Text + ",'" + DropDownList1.SelectedValue + "','" + txtsubject.Text + "')", cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        DropDownList1.ClearSelection()
        txtsubject.Text = ""
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Subject_Id", MsgBoxStyle.Exclamation)
        Else

            Dim update As String
            update = "UPDATE Subject SET [Subject]='" + txtsubject.Text + "' WHERE[Subject_Id]=" + TextBox1.Text + ""
            cmd = New OleDbCommand(update, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
    End Sub

    Protected Sub btnfind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfind.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Subject_Id", MsgBoxStyle.Exclamation)
        Else
            Dim dr As OleDbDataReader
            cmd = New OleDbCommand("select * from Subject where Subject_Id=" + TextBox1.Text, cn)
            dr = cmd.ExecuteReader()
            dr.Read()
            DropDownList1.SelectedValue = dr("Class").ToString()
            txtsubject.Text = dr("Subject").ToString()
        End If

        cn.Close()
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Subject_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("delete from Subject where Subject_Id= " + TextBox1.Text, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        TextBox1.Text = ""
        txtsubject.Text = ""
        DropDownList1.ClearSelection()
        data()
    End Sub

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Subject_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("select * from Subject where Subject_Id=" + TextBox1.Text, cn)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If

        cn.Close()
    End Sub

End Class
