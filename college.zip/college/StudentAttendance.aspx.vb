﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class SchoolAttendance

    Inherits System.Web.UI.Page
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Prince\Documents\Visual Studio 2010\Projects\college\Database9.accdb"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGridView()
        End If
    End Sub
    Private Sub BindGridView()
        Dim query As String = "SELECT Student_Id, Student_Name FROM StudentAdd"
        Dim connection As New OleDbConnection(connectionString)
        Dim adapter As New OleDbDataAdapter(query, connection)
        Dim dataset As New DataSet()

        adapter.Fill(dataset)

        If dataset.Tables.Count > 0 Then
            GridView1.DataSource = dataset.Tables(0)
            GridView1.DataBind()
        End If

        connection.Close()
    End Sub

    Protected Sub MarkAttendance_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim connection As New OleDbConnection(connectionString)
        connection.Open()

        Dim currentDate As DateTime = DateTime.Now.Date

        For Each row As GridViewRow In GridView1.Rows
            Dim studentID As String = row.Cells(0).Text
            Dim rblAttendance As RadioButtonList = DirectCast(row.FindControl("rblAttendance"), RadioButtonList)
            Dim attendanceValue As String = rblAttendance.SelectedValue

            ' Insert attendance record into the database
            Dim insertQuery As String = "INSERT INTO AttendanceStd (Student_Id, AttendanceStatus, AttendanceDate) VALUES (@Student_Id, @AttendanceStatus, @AttendanceDate)"
            Dim insertCommand As New OleDbCommand(insertQuery, connection)
            insertCommand.Parameters.AddWithValue("@Student_Id", studentID)
            insertCommand.Parameters.AddWithValue("@AttendanceStatus", attendanceValue)
            insertCommand.Parameters.AddWithValue("@AttendanceDate", currentDate)
            insertCommand.ExecuteNonQuery()
        Next

        connection.Close()

        ' Refresh the GridView after marking attendance
        BindGridView()

        Dim script As String = "alert('Attendance saved in the database.');"
        ClientScript.RegisterStartupScript(Me.GetType(), "AlertScript", script, True)
    End Sub
End Class
